package com.eeae.Vega;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication 
public class VegaApplication {

    public static void main(String[] args) {
        SpringApplication.run(VegaApplication.class, args);
    }

}
